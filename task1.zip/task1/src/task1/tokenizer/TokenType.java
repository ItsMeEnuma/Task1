package task1.tokenizer;

public enum  TokenType {
    ID, INT, OP, LB, RB
}
